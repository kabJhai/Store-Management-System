<?php
/**
 * Created by PhpStorm.
 * User: kabil
 * Date: 7/13/2018
 * Time: 11:01 PM
 */
?>
<link href="css/style.css" rel="stylesheet">
<link rel="icon" href="images/logo.png">
<script rel="script" src="scripts/app.js"></script>
<script src=" scripts/jquery/jquery-2.2.4.min.js"></script>
<script rel="script" src="scripts/plugins.js"></script>
