<?php
/**
 * Created by PhpStorm.
 * User: kabil
 * Date: 7/11/2018
 * Time: 11:51 PM
 */
 include "includes/session.php";
?>
<html>
    <head>
        <title>Waldaa Birhana Kiristoos Goojjoo Lakkoofsa Tokko</title>
        <?php include "includes/style_links.php";?>
        <script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-7243602708958043",
    enable_page_level_ads: true
  });
</script>
    </head>
    <body>

        <aside>
            <?php include "includes/left_navigation.php";?>
        </aside>
        <section class="main_body">
            <img class="center-logo" src="images/logo.png"/>
            <p id="page_title">
                Marsariitii Waldaa Birhana Kiristoos Goojjootti Baga Nagaaan Dhuftan.
            </p>
            <p id="page_content">
                Marsariitiin kun miseensota waldaa kanaa qindeessuuf akkasumas to'achuuf Waldaa kanaaf qofa kan kennamedha.
                <ul class="feature_list animated fadeInDown">
                Ani Kaabilaa Hayilee Sobbooqaa marsariitii kana Waldaa koo Waldaa Birhana Kiristoos Goojjoottiif kanin hojjedhe yemmuu ta'u marsariitii kana
                kanin hojjedhe bara 2010 A.L.H yookin bara 2018 A.L.A yookin 6012 A.L.O yemmuu ta'u marsariitiin kun koodii sarara <strong>Kuma Torbaafii Dhibba Sadiif Digdami Saddeet (7328)</strong> ol kan qabu yemmuu ta'u
                akkasumas qubee <strong>Kuma dhibba Afuriifii Kuma Afurtami Sagaliif Dhibba Afuriif Sagaltami Shanii ol (449,495)</strong>   kan of keessatti qabatedha.<br/>
                Wantoota ta'aniifi hojjetaman hundumaa keessatti isa na gargaare Waaqayyo maqaan isaa kan eebbifame haa ta'u.
                <br/><em>Wanti hundumtuu isaan ta'e isaan alas kan ta'e tokkollee hin jiru.</em><br/><strong>Wangeela Yohaannis 1:3</strong><br/>
                <strong>Kaabilaa Hayilee Sobbooqaa<br>Lakkoofsa Bilbilaa :0923141180 / 0924303291 / 0909841411<br>Iimelii : kabilahaile@gmail.com</strong>
            </ul>
            </p>
        </section>
    </body>


</html>

