<?php
/**
 * Created by PhpStorm.
 * User: K4K
 * Date: 19/02/2018
 * Time: 3:39 AM
 */
header("Location:../404");